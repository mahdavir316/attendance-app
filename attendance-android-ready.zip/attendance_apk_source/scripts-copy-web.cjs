const fs = require('fs');
const path = require('path');
const files = ['index.html', 'manifest.json', 'sw.js', 'icon-192.png', 'icon-512.png'];
fs.mkdirSync('www', { recursive: true });
for (const file of files) fs.copyFileSync(file, path.join('www', file));
console.log('Web files copied to www/');
